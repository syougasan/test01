from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import *
import json
import os
from flask_socketio import SocketIO, emit

APP = Flask(__name__)
APP.config['SECRET_KEY']                     = os.urandom(24)
APP.config['SQLALCHEMY_DATABASE_URI']        = 'postgresql://postgres@172.16.100.40/pptest'
APP.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
SOK = SocketIO(APP)
DB  = SQLAlchemy(APP)
SOK_CON_CNT = 0

class m_linked_org(DB.Model):
    __tablename__               = 'm_linked_org'
    linked_org_id               = DB.Column(DB.Text, primary_key=True)
    linked_org_nm               = DB.Column(DB.Text)
    linked_org_auth_cd          = DB.Column(DB.Text)
    linked_org_profile_business = DB.Column(DB.Text)
    linked_org_profile_msg      = DB.Column(DB.Text)
    linked_org_profile_img_file = DB.Column(DB.Text)
    stop_flg                    = DB.Column(DB.SmallInteger)

class m_linked_org_member(DB.Model):
    __tablename__               = 'm_linked_org_menber'
    linked_org_id               = DB.Column(DB.Text, primary_key=True)
    org_id                      = DB.Column(DB.Text, primary_key=True)

class m_linked_org_auth(DB.Model):
    __tablename__               = 'm_linked_org_auth'
    linked_org_auth_cd          = DB.Column(DB.Text, primary_key=True)
    linked_org_auth_nm          = DB.Column(DB.Text)
    fnc_other_org_online_flg    = DB.Column(DB.SmallInteger)
    fnc_other_org_profile_flg   = DB.Column(DB.SmallInteger)
    fnc_other_org_talk_flg      = DB.Column(DB.SmallInteger)
    fnc_other_org_voice_flg     = DB.Column(DB.SmallInteger)
    fnc_other_org_search_flg    = DB.Column(DB.SmallInteger)
    fnc_other_org_analyze_flg   = DB.Column(DB.SmallInteger)
    fnc_other_org_footprint_flg = DB.Column(DB.SmallInteger)
    fnc_other_org_notice_flg    = DB.Column(DB.SmallInteger)

class t_linked_org_msg(DB.Model):
    __tablename__       = 't_linked_org_msg'
    linked_org_id       = DB.Column(DB.Text, primary_key=True)
    linked_org_msg_id   = DB.Column(DB.BigInteger, Sequence('t_linked_org_msg_seq'), primary_key=True)
    linked_org_msg_dtm  = DB.Column(DB.TIMESTAMP, default=func.now())
    linked_org_msg_type = DB.Column(DB.Text)
    linked_org_msg      = DB.Column(DB.Text)
    send_org_id         = DB.Column(DB.Text)
    send_user_id        = DB.Column(DB.Text)

class m_org(DB.Model):
    __tablename__        = 'm_org'
    org_id               = DB.Column(DB.Text, primary_key=True)
    org_nm               = DB.Column(DB.Text)
    org_pass             = DB.Column(DB.Text)
    org_auth_cd          = DB.Column(DB.Text)
    org_profile_business = DB.Column(DB.Text)
    org_profile_address  = DB.Column(DB.Text)
    org_profile_msg      = DB.Column(DB.Text)
    org_profile_img_file = DB.Column(DB.Text)
    stop_flg             = DB.Column(DB.SmallInteger)

class m_org_auth(DB.Model):
    __tablename__             = 'm_org_auth'
    org_auth_cd               = DB.Column(DB.Text, primary_key=True)
    org_auth_nm               = DB.Column(DB.Text)
    fnc_one_talk_flg          = DB.Column(DB.SmallInteger)
    fnc_group_talk_flg        = DB.Column(DB.SmallInteger)
    fnc_org_talk_flg          = DB.Column(DB.SmallInteger)
    talk_read_flg             = DB.Column(DB.SmallInteger)
    talk_notice_flg           = DB.Column(DB.SmallInteger)
    talk_img_flg              = DB.Column(DB.SmallInteger)
    talk_stamp_flg            = DB.Column(DB.SmallInteger)
    talk_del_flg              = DB.Column(DB.SmallInteger)
    talk_sanitize_flg         = DB.Column(DB.SmallInteger)
    fnc_voice_flg             = DB.Column(DB.SmallInteger)
    voice_share_flg           = DB.Column(DB.SmallInteger)
    voice_good_flg            = DB.Column(DB.SmallInteger)
    voice_comment_flg         = DB.Column(DB.SmallInteger)
    voice_sanitize_flg        = DB.Column(DB.SmallInteger)
    fnc_setting_flg           = DB.Column(DB.SmallInteger)
    setting_user_mng_flg      = DB.Column(DB.SmallInteger)
    setting_user_auth_mng_flg = DB.Column(DB.SmallInteger)
    setting_img_mng_flg       = DB.Column(DB.SmallInteger)
    setting_stamp_mng_flg     = DB.Column(DB.SmallInteger)
    setting_sound_mng_flg     = DB.Column(DB.SmallInteger)
    setting_tag_mng_flg       = DB.Column(DB.SmallInteger)
    setting_footprint_mng_flg = DB.Column(DB.SmallInteger)
    fnc_tag_profile_flg       = DB.Column(DB.SmallInteger)
    tag_profile_limit         = DB.Column(DB.SmallInteger)
    fnc_tag_voice_flg         = DB.Column(DB.SmallInteger)
    tag_voice_limit           = DB.Column(DB.SmallInteger)
    fnc_search_flg            = DB.Column(DB.SmallInteger)
    search_org_flg            = DB.Column(DB.SmallInteger)
    search_user_flg           = DB.Column(DB.SmallInteger)
    search_profile_tag_flg    = DB.Column(DB.SmallInteger)
    search_voice_tag_flg      = DB.Column(DB.SmallInteger)
    fnc_analyze_flg           = DB.Column(DB.SmallInteger)
    analyze_one_talk_flg      = DB.Column(DB.SmallInteger)
    analyze_group_talk_flg    = DB.Column(DB.SmallInteger)
    analyze_voice_flg         = DB.Column(DB.SmallInteger)
    analyze_access_flg        = DB.Column(DB.SmallInteger)
    fnc_online_flg            = DB.Column(DB.SmallInteger)
    online_last_login_flg     = DB.Column(DB.SmallInteger)
    fnc_footprint_flg         = DB.Column(DB.SmallInteger)
    footprint_del_flg         = DB.Column(DB.SmallInteger)
    fnc_link_flg              = DB.Column(DB.SmallInteger)
    link_limit                = DB.Column(DB.SmallInteger)

class m_user(DB.Model):
    __tablename__    = 'm_user'
    org_id           = DB.Column(DB.Text, primary_key=True)
    user_id          = DB.Column(DB.Text, primary_key=True)
    user_nm          = DB.Column(DB.Text)
    user_pass        = DB.Column(DB.Text)
    user_auth_cd     = DB.Column(DB.Text)
    profile_work     = DB.Column(DB.Text)
    profile_msg      = DB.Column(DB.Text)
    profile_img_file = DB.Column(DB.Text)
    stop_flg         = DB.Column(DB.SmallInteger)

class m_user_auth(DB.Model):
    __tablename__              = 'm_user_auth'
    user_auth_cd               = DB.Column(DB.Text, primary_key=True)
    user_auth_nm               = DB.Column(DB.Text)
    site_base_collor           = DB.Column(DB.Text)
    site_position_type         = DB.Column(DB.Text)
    talk_one_flg               = DB.Column(DB.SmallInteger)
    talk_one_make_flg          = DB.Column(DB.SmallInteger)
    talk_group_flg             = DB.Column(DB.SmallInteger)
    talk_group_make_flg        = DB.Column(DB.SmallInteger)
    talk_org_flg               = DB.Column(DB.SmallInteger)
    talk_linked_org_flg        = DB.Column(DB.SmallInteger)
    management_flg             = DB.Column(DB.SmallInteger)
    analyze_flg                = DB.Column(DB.SmallInteger)
    notice_sound_nm            = DB.Column(DB.Text)
    notice_talk_one_flg        = DB.Column(DB.SmallInteger)
    notice_talk_group_flg      = DB.Column(DB.SmallInteger)
    notice_talk_org_flg        = DB.Column(DB.SmallInteger)
    notice_talk_linked_org_flg = DB.Column(DB.SmallInteger)
    notice_voice_share_flg     = DB.Column(DB.SmallInteger)
    notice_voice_good_flg      = DB.Column(DB.SmallInteger)
    notice_voice_comment_flg   = DB.Column(DB.SmallInteger)
    notice_online_flg          = DB.Column(DB.SmallInteger)

class t_user_status(DB.Model):
    __tablename__ = 't_user_status'
    org_id        = DB.Column(DB.Text, primary_key=True)
    user_id       = DB.Column(DB.Text, primary_key=True)
    status        = DB.Column(DB.Text)
    upd_dtm       = DB.Column(DB.TIMESTAMP, default=func.now())

class t_user_config_user(DB.Model):
    __tablename__  = 't_user_config_user'
    org_id         = DB.Column(DB.Text, primary_key=True)
    user_id        = DB.Column(DB.Text, primary_key=True)
    config_org_id  = DB.Column(DB.Text, primary_key=True)
    config_user_id = DB.Column(DB.Text, primary_key=True)
    disp_flg       = DB.Column(DB.SmallInteger)
    disp_seq       = DB.Column(DB.BigInteger)
    bg_img_nm      = DB.Column(DB.Text)
    bg_color_nm    = DB.Column(DB.Text)
    notice_msg_flg = DB.Column(DB.SmallInteger)

class t_user_visit(DB.Model):
    __tablename__      = 't_user_visit'
    seq                = DB.Column(DB.BigInteger, Sequence('t_user_visit_seq'), primary_key=True)
    org_id             = DB.Column(DB.Text, primary_key=True)
    user_id            = DB.Column(DB.Text, primary_key=True)
    user_visit_org_id  = DB.Column(DB.Text)
    user_visit_user_id = DB.Column(DB.Text)
    user_visit_dtm     = DB.Column(DB.Text)

class t_user_voice(DB.Model):
    __tablename__ = 't_user_voice'
    org_id        = DB.Column(DB.Text)
    user_id       = DB.Column(DB.Text)
    voice_id      = DB.Column(DB.BigInteger, Sequence('t_user_voice_seq'), primary_key=True)
    voice_dtm     = DB.Column(DB.TIMESTAMP, default=func.now())
    voice         = DB.Column(DB.Text)
    hide_flg      = DB.Column(DB.SmallInteger)

class t_user_voice_report(DB.Model):
    __tablename__  = 't_user_voice_report'
    voice_id       = DB.Column(DB.BigInteger, primary_key=True)
    report_org_id  = DB.Column(DB.Text, primary_key=True)
    report_user_id = DB.Column(DB.Text, primary_key=True)
    report_dtm     = DB.Column(DB.TIMESTAMP, default=func.now())

class t_user_voice_comment(DB.Model):
    __tablename__     = 't_user_voice_comment'
    voice_id          = DB.Column(DB.BigInteger, primary_key=True)
    voice_comment_dtm = DB.Column(DB.TIMESTAMP, default=func.now())
    voice_comment     = DB.Column(DB.Text)
    comment_org_id    = DB.Column(DB.Text, primary_key=True)
    comment_user_id   = DB.Column(DB.Text, primary_key=True)
    hide_flg          = DB.Column(DB.SmallInteger)

class t_user_voice_comment_report(DB.Model):
    __tablename__   = 't_user_voice_comment_report'
    voice_id        = DB.Column(DB.BigInteger, primary_key=True)
    comment_org_id  = DB.Column(DB.Text, primary_key=True)
    comment_user_id = DB.Column(DB.Text, primary_key=True)
    report_org_id   = DB.Column(DB.Text, primary_key=True)
    report_user_id  = DB.Column(DB.Text, primary_key=True)
    report_dtm      = DB.Column(DB.TIMESTAMP, default=func.now())

class t_user_voice_good(DB.Model):
    __tablename__ = 't_user_voice_good'
    voice_id      = DB.Column(DB.BigInteger, primary_key=True)
    good_dtm      = DB.Column(DB.TIMESTAMP, default=func.now())
    good_org_id   = DB.Column(DB.Text, primary_key=True)
    good_user_id  = DB.Column(DB.Text, primary_key=True)

class t_user_voice_follow(DB.Model):
    __tablename__  = 't_user_voice_follow'
    org_id         = DB.Column(DB.Text, primary_key=True)
    user_id        = DB.Column(DB.Text, primary_key=True)
    follow_org_id  = DB.Column(DB.Text, primary_key=True)
    follow_user_id = DB.Column(DB.Text, primary_key=True)

class t_user_talk_msg(DB.Model):
    __tablename__ = 't_user_talk_msg'
    talk_msg_id   = DB.Column(DB.BigInteger, Sequence('t_user_talk_msg_seq'), primary_key=True)
    talk_msg_dtm  = DB.Column(DB.TIMESTAMP, default=func.now())
    talk_msg_type = DB.Column(DB.Text) #img or text
    talk_msg      = DB.Column(DB.Text)
    send_org_id   = DB.Column(DB.Text)
    send_user_id  = DB.Column(DB.Text)
    resv_org_id   = DB.Column(DB.Text)
    resv_user_id  = DB.Column(DB.Text)
    resv_chk_flg  = DB.Column(DB.SmallInteger)
    hide_flg      = DB.Column(DB.SmallInteger)

class t_user_talk_msg_report(DB.Model):
    __tablename__  = 't_user_talk_msg_report'
    talk_msg_id    = DB.Column(DB.BigInteger, primary_key=True)
    report_org_id  = DB.Column(DB.Text, primary_key=True)
    report_user_id = DB.Column(DB.Text, primary_key=True)
    report_dtm     = DB.Column(DB.TIMESTAMP, default=func.now())

class t_all_msg(DB.Model):
    __tablename__ = 't_all_msg'
    all_msg_id    = DB.Column(DB.BigInteger, Sequence('t_all_msg_seq'), primary_key=True)
    all_msg_dtm   = DB.Column(DB.TIMESTAMP, default=func.now())
    all_msg_type  = DB.Column(DB.Text) #img or text
    all_msg       = DB.Column(DB.Text)
    send_org_id   = DB.Column(DB.Text)
    send_user_id  = DB.Column(DB.Text)
    hide_flg      = DB.Column(DB.SmallInteger)

class t_all_msg_report(DB.Model):
    __tablename__  = 't_all_msg_report'
    all_msg_id     = DB.Column(DB.BigInteger, primary_key=True)
    report_org_id  = DB.Column(DB.Text, primary_key=True)
    report_user_id = DB.Column(DB.Text, primary_key=True)
    report_dtm     = DB.Column(DB.TIMESTAMP, default=func.now())

class t_all_msg_comment(DB.Model):
    __tablename__       = 't_all_msg_comment'
    all_msg_id          = DB.Column(DB.BigInteger, primary_key=True)
    all_msg_comment_dtm = DB.Column(DB.TIMESTAMP, default=func.now())
    all_msg_comment     = DB.Column(DB.Text)
    comment_org_id      = DB.Column(DB.Text, primary_key=True)
    comment_user_id     = DB.Column(DB.Text, primary_key=True)
    hide_flg            = DB.Column(DB.SmallInteger)

class t_all_msg_comment_report(DB.Model):
    __tablename__   = 't_all_msg_comment_report'
    all_msg_id      = DB.Column(DB.BigInteger, primary_key=True)
    comment_org_id  = DB.Column(DB.Text, primary_key=True)
    comment_user_id = DB.Column(DB.Text, primary_key=True)
    report_org_id   = DB.Column(DB.Text, primary_key=True)
    report_user_id  = DB.Column(DB.Text, primary_key=True)
    report_dtm      = DB.Column(DB.TIMESTAMP, default=func.now())

class t_all_msg_chk(DB.Model):
    __tablename__   = 't_all_msg_chk'
    seq             = DB.Column(DB.BigInteger, Sequence('t_all_msg_chk_seq'), primary_key=True)
    all_msg_id      = DB.Column(DB.Text, primary_key=True)
    all_msg_chk_dtm = DB.Column(DB.TIMESTAMP, default=func.now())
    chk_org_id      = DB.Column(DB.Text)
    chk_user_id     = DB.Column(DB.Text)

# class t_group_talk(DB.Model):
#     __tablename__  = 't_group_talk'
#     org_id         = DB.Column(DB.Text, primary_key=True)
#     group_talk_id   = DB.Column(DB.SmallInteger, Sequence('t_group_talk_seq'), primary_key=True)
#     group_talk_nm   = DB.Column(DB.Text)
#     group_talk_type = DB.Column(DB.Text) #1:1 group
# 
# class t_group_talk_member(DB.Model):
#     __tablename__      = 't_group_talk_member'
#     org_id             = DB.Column(DB.Text, primary_key=True)
#     group_talk_id = DB.Column(DB.SmallInteger, primary_key=True)
#     user_id            = DB.Column(DB.Text, primary_key=True)
# 
# class t_group_talk_msg(DB.Model):
#     __tablename__       = 't_group_talk_msg'
#     org_id              = DB.Column(DB.Text, primary_key=True)
#     group_talk_id  = DB.Column(DB.SmallInteger, primary_key=True)
#     group_talk_msg_id   = DB.Column(DB.SmallInteger, Sequence('t_group_talk_msg_seq'), primary_key=True)
#     group_talk_msg_dtm  = DB.Column(DB.TIMESTAMP, default=func.now())
#     group_talk_msg_type = DB.Column(DB.Text) #img or text
#     group_talk_msg      = DB.Column(DB.Text)
#     send_org_id         = DB.Column(DB.Text)
#     send_user_id        = DB.Column(DB.Text)
# 
# class t_group_talk_msg_chk(DB.Model):
#     __tablename__          = 't_group_talk_msg_chk'
#     group_talk_id     = DB.Column(DB.SmallInteger, primary_key=True)
#     group_talk_msg_id      = DB.Column(DB.Text, primary_key=True)
#     group_talk_msg_chk_dtm = DB.Column(DB.TIMESTAMP, default=func.now())
#     chk_org_id             = DB.Column(DB.Text, primary_key=True)
#     chk_user_id            = DB.Column(DB.Text, primary_key=True)

class t_access_log(DB.Model):
    __tablename__  = 't_access_log'
    access_log_seq = DB.Column(DB.BigInteger, Sequence('t_access_log_seq'), primary_key=True)
    ip             = DB.Column(DB.Text)
    url            = DB.Column(DB.Text)
    org_id         = DB.Column(DB.Text)
    user_id        = DB.Column(DB.Text)
    access_dtm     = DB.Column(DB.TIMESTAMP, default=func.now())

# 手修正可能なテーブルは記録する
class t_edit_log(DB.Model):
    __tablename__ = 't_edit_log'
    edit_log_seq  = DB.Column(DB.BigInteger, Sequence('t_edit_log_seq'), primary_key=True)
    table_id      = DB.Column(DB.Text)
    table_key     = DB.Column(DB.Text)
    org_id        = DB.Column(DB.Text)
    user_id       = DB.Column(DB.Text)
    edit_dtm      = DB.Column(DB.TIMESTAMP, default=func.now())

class m_filter(DB.Model):
    __tablename__ = 'm_filter'
    filter_id     = DB.Column(DB.Text, primary_key=True)
    filter_kbn    = DB.Column(DB.Text)
    filter_text   = DB.Column(DB.Text)

def _create_access_log(url):
    log = t_access_log(org_id=session.get('orgid')
                      ,user_id=session.get('userid')
                      ,ip=request.remote_addr
                      ,url=url
                      )
    DB.session.add(log)
    DB.session.commit()

@APP.before_request
def before_request():
    # 不正アクセス
    # if ～
    if session.get('orgid') is not None and session.get('userid') is not None:
        return
    if request.path == '/login':
        return
    if request.path == '/static/css/AdminLTE.min.css':
        return
    return redirect('/login')

@APP.route('/login', methods=['GET', 'POST'])
def login():
    _create_access_log('/login')
    if request.method == 'POST':
        if _is_account_valid():
            session['orgid']  = request.form['orgid']
            session['userid'] = request.form['userid']
            return redirect(url_for('index'))
        else:
            return render_template('login.html', errmsg="ログイン情報に誤りがあります")
    return render_template('login.html')

def _is_account_valid():
    orgid    = request.form.get('orgid')
    userid   = request.form.get('userid')
    password = request.form.get('password')
    org_rst  = DB.session.query(m_org
                    ).filter(
                        and_(m_org.org_id == orgid
                            ,m_org.stop_flg == 0
                            )
                    ).first()
    user_rst = DB.session.query(m_user
                    ).filter(
                        and_(m_user.org_id == orgid
                            ,m_user.user_id == userid
                            ,m_user.user_pass == password
                            ,m_user.stop_flg == 0
                            )
                    ).first()
    if org_rst is not None and user_rst is not None:
        session['orgnm']  = org_rst.org_nm
        session['usernm'] = user_rst.user_nm
        return True
    return False

@APP.route('/logout')
def logout():
    _create_access_log('/logout')
    session.pop('orgid', None)
    session.pop('orgnm', None)
    session.pop('userid', None)
    session.pop('usernm', None)
    return redirect(url_for('login'))

@APP.route('/')
def index():
    _create_access_log('/index')
    try:
        rst_login_user = DB.session.query(m_user
                            ).filter(
                                and_(m_user.org_id == session.get('orgid')
                                    ,m_user.user_id == session.get('userid')
                                    )
                            ).first()
        sql_m_user = """
            select c.org_id
                  ,c.org_nm
                  ,a.user_id
                  ,a.user_nm
                  ,a.user_auth_cd
                  ,a.profile_work
                  ,a.profile_msg
                  ,a.profile_img_file
                  ,b.status
                  ,b.upd_dtm
              from m_user a left join t_user_status b on (a.org_id = b.org_id and a.user_id   = b.user_id)
                 , m_org c
             where (a.org_id, a.user_id) not in (
                select d.org_id, d.user_id
                  from m_user d
                 where d.org_id  = '@LOGIN_ORG_ID@'
                   and d.user_id = '@LOGIN_USER_ID@'
                )
               and a.org_id = c.org_id
             order by a.org_id, a.user_id
        """
        sql_m_user = sql_m_user.replace("@LOGIN_ORG_ID@" ,session.get('orgid'))
        sql_m_user = sql_m_user.replace("@LOGIN_USER_ID@",session.get('userid'))
        rst_m_user = DB.session.execute(sql_m_user)
        rst_m_user = list(rst_m_user)
        # APP.logger.debug(vars(rst_m_user.context))
        # rst_ins_user_aft_login_user = DB.session.query(m_user
        #                                               ,func.to_char(m_user.ins_dtm, 'YYYY-MM-dd')
        #                                 ).filter(
        #                                     and_(m_user.user_id != 'u001' # session.get('userid')
        #                                         ,m_user.ins_dtm >= rst_login_user.login_last_dtm)
        #                                 ).all()
        # rst_msg_aft_login_user = DB.session.query(m_user
        #                                          ,func.to_char(m_user.ins_dtm, 'YYYY-MM-dd')
        #                                 ).filter(
        #                                     and_(m_user.user_id != 'u001' # session.get('userid')
        #                                         ,m_user.ins_dtm >= rst_login_user.login_last_dtm)
        #                                 ).all()
    except Exception as e:
        APP.logger.debug(e)

#    return render_template('profile.html'
    return render_template('index.html'
                          ,rst_m_user=rst_m_user
                          ,rst_login_user=rst_login_user
                          ,now_dtm=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                          )
#                          ,rst_ins_user_aft_login_user=rst_ins_user_aft_login_user

@APP.route('/profile', methods=['GET'])
def profile():
    _create_access_log('/profile')
    return render_template('profile.html')

@APP.route('/search')
def search():
    _create_access_log('/search')
    return render_template('search.html')

@APP.route('/management')
def management():
    _create_access_log('/management')
    return render_template('management.html')

@APP.route('/analyze')
def analyze():
    _create_access_log('/analyze')
    return render_template('analyze.html')

@APP.route('/api/grid/user/search')
def api_grid_user_search():
    """
    # 処理： [Grid_Handsontable]ユーザーマスタ取得処理
    # 概要： 
    # 備考： 
    """
    rst_m_user = DB.session.query(m_user
                    ).order_by(m_user.user_id
                    ).all()
    outer_lst  = []
    for r in rst_m_user:
        inner_lst = []
        inner_lst.append(r.user_id)
        inner_lst.append(r.user_nm)
        inner_lst.append(r.user_pass)
        inner_lst.append(r.user_auth_cd)
        inner_lst.append(r.user_profile_work)
        inner_lst.append(r.user_profile_msg)
        inner_lst.append(r.user_profile_img_file)
        inner_lst.append(r.stop_flg)
        outer_lst.append(inner_lst)
    return jsonify(outer_lst)

@APP.route('/api/grid/user/commit', methods=['POST'])
def api_grid_user_commit():
    """
    # 処理： [Grid_Handsontable]ユーザーマスタ追加処理
    # 概要： 
    # 備考： 
    """
    i   = 0
    rst = ""
    while True:
        target     = 'data[' + str(i) +'][]'
        rsv_record = request.form.getlist(target)
        add_record = []
        for r in request.form.getlist(target):
            add_record.append(r)
        if add_record != []:
            DB.session.query(m_user
                    ).filter(m_user.user_id == add_record[0]
                    ).delete()
            user = m_user(org_id='1'
                         ,user_id=add_record[0]
                         ,user_nm=add_record[1]
                         ,user_pass=add_record[2]
                         ,user_auth_cd=add_record[3]
                         ,user_profile_work=add_record[4]
                         ,user_profile_msg=add_record[5]
                         ,user_profile_img_file=add_record[6]
                         ,stop_flg=add_record[7]
                         )
            DB.session.add(user)
            i += 1
        else:
            try:
                DB.session.commit()
                rst = "OK"
            except Exception as e:
                DB.session.rollback()
                APP.logger.debug(e)
                rst = "NG"
            break
    return rst

@SOK.on('my_event', namespace='/sok')
def sok_chat_message(message):
    import urllib.parse
    aaa = message['data']
    bbb = urllib.parse.unquote(aaa)
    cht = t_chat_one_to_one(msg=bbb
                           ,send_user_id=session.get('userid')
                           ,resv_user_id="hoge"
                           )
    DB.session.add(cht)
    DB.session.commit()
    now = datetime.now().strftime("%Y/%m/%d %H:%M:%S")
    emit('my_response'
        , {
            'data': bbb
           ,'dtm' : now
           ,'send_user_id' : session.get('userid')
           ,'resv_user_id' : "hoge"
          }
        ,broadcast=True
        )

@SOK.on('sok_srv_add_voice_comment', namespace='/sok')
def sok_srv_add_voice_comment(message):
    """
    # 処理： [Socket.io]ボイスコメント追加処理
    # 概要： 
    # 備考： 
    """
    voice_id      = message['voice_id']
    voice_comment = message['voice_comment']
    comment       = t_user_voice_comment(voice_id=voice_id
                                        ,voice_comment=voice_comment
                                        ,comment_org_id=session.get('orgid')
                                        ,comment_user_id=session.get('userid')
                                        ,hide_flg=0
                                        )
    DB.session.add(comment)
    DB.session.commit()

    login_user = DB.session.query(m_user
                ).filter(
                    and_(m_user.org_id == session.get('orgid')
                        ,m_user.user_id == session.get('userid')
                        )
                ).first()
    if login_user is not None:
        w_comment_user_nm       = login_user.user_nm
        w_comment_user_img_file = login_user.profile_img_file

    sql_voice_user = """
        select c.org_id
              ,c.org_nm
              ,b.user_id
              ,b.user_nm
              ,b.profile_img_file
              ,a.voice
              ,a.voice_dtm
          from t_user_voice a
              ,m_user b
              ,m_org c
         where a.org_id    = b.org_id
           and a.user_id   = b.user_id
           and b.org_id    = c.org_id
           and a.voice_id  = @VOICE_ID@
         limit 1
    """
    sql_voice_user = sql_voice_user.replace("@VOICE_ID@",str(voice_id))
    rst_voice_user = DB.session.execute(sql_voice_user)
    rst_voice_user = list(rst_voice_user)
    for r in rst_voice_user:
        w_voice_org_id        = r.org_id
        w_voice_org_nm        = r.org_nm
        w_voice_user_id       = r.user_id
        w_voice_user_nm       = r.user_nm
        w_voice_user_img      = r.profile_img_file

    emit('sok_cli_add_voice_comment'
        , {
            'comment_org_id'  : session.get('orgid')
           ,'comment_user_id' : session.get('userid')
           ,'comment_user_nm' : w_comment_user_nm
           ,'comment_user_img': w_comment_user_img_file
           ,'voice_comment'   : voice_comment
           ,'voice_org_id'    : w_voice_org_id
           ,'voice_org_nm'    : w_voice_org_nm
           ,'voice_user_id'   : w_voice_user_id
           ,'voice_user_nm'   : w_voice_user_nm
          }
        , broadcast=True
        )

@SOK.on('sok_srv_add_voice_good', namespace='/sok')
def sok_srv_add_voice_good(message):
    """
    # 処理： [Socket.io]ボイスGood追加処理
    # 概要： 
    # 備考： 
    """
    voice_id = message['voice_id']
    good     = t_user_voice_good(voice_id=voice_id
                                ,good_org_id=session.get('orgid')
                                ,good_user_id=session.get('userid')
                                )
    DB.session.add(good)
    DB.session.commit()

@SOK.on('sok_srv_add_voice_report', namespace='/sok')
def sok_srv_add_voice_report(message):
    """
    # 処理： [Socket.io]ボイス報告追加処理
    # 概要： 
    # 備考： 
    """
    voice_id = message['voice_id']
    report   = t_user_voice_report(voice_id=voice_id
                                  ,report_org_id=session.get('orgid')
                                  ,report_user_id=session.get('userid')
                                  )
    DB.session.add(report)
    DB.session.commit()

@SOK.on('sok_srv_add_voice_comment_report', namespace='/sok')
def sok_srv_add_voice_comment_report(message):
    """
    # 処理： [Socket.io]ボイスコメント報告追加処理
    # 概要： 
    # 備考： 
    """
    voice_id = message['voice_id']
    org_id   = message['org_id']
    user_id  = message['user_id']
    report   = t_user_voice_comment_report(voice_id=voice_id
                                          ,comment_org_id=org_id
                                          ,comment_user_id=user_id
                                          ,report_org_id=session.get('orgid')
                                          ,report_user_id=session.get('userid')
                                          )
    DB.session.add(report)
    DB.session.commit()

@SOK.on('sok_srv_ini_index', namespace='/sok')
def sok_srv_ini_index(message):
    """
    # 処理： [Socket.io]index.html初期化処理
    # 概要： 
    # 備考： 
    """
    org_id  = message['org_id']
    user_id = message['user_id']
    # ----------------------------------------------------
    # 発信者
    # ----------------------------------------------------
    # データ取得
    sql_voice = """
        select c.org_id
              ,c.org_nm
              ,b.user_id
              ,b.user_nm
              ,b.profile_img_file
              ,a.voice_id
              ,a.voice
              ,a.voice_dtm
          from t_user_voice a
              ,m_user b
              ,m_org c
         where a.org_id    = b.org_id
           and a.user_id   = b.user_id
           and b.org_id    = c.org_id
           and a.org_id    = '@ORG_ID@'
           and a.user_id   = '@USER_ID@'
         order by voice_id desc
         limit 100
    """
    sql_voice = sql_voice.replace("@ORG_ID@",org_id)
    sql_voice = sql_voice.replace("@USER_ID@",user_id)
    rst_voice = DB.session.execute(sql_voice)
    rst_voice = list(rst_voice)
    for r in rst_voice:
        # データ送信
        emit('sok_cli_ini_voice'
            , {
                'org_id' : r.org_id
               ,'org_nm' : r.org_nm
               ,'user_id': r.user_id
               ,'user_nm': r.user_nm
               ,'profile_img_file': r.profile_img_file
               ,'voice_id' : r.voice_id
               ,'voice_dtm': r.voice_dtm.strftime("%Y/%m/%d %H:%M:%S")
               ,'voice'    : r.voice
              }
            )
        # ----------------------------------------------------
        # ログインユーザー
        # ----------------------------------------------------
        # データ取得
        v_login_user = DB.session.query(m_user
                    ).filter(
                        and_(m_user.org_id == session.get('orgid')
                            ,m_user.user_id == session.get('userid')
                            )
                    ).first()
        v_login_comment = DB.session.query(t_user_voice_comment
                    ).filter(
                        and_(t_user_voice_comment.comment_org_id == session.get('orgid')
                            ,t_user_voice_comment.comment_user_id == session.get('userid')
                            ,t_user_voice_comment.voice_id == r.voice_id
                            )
                    ).first()
        v_login_good = DB.session.query(t_user_voice_good
                    ).filter(
                        and_(t_user_voice_good.good_org_id == session.get('orgid')
                            ,t_user_voice_good.good_user_id == session.get('userid')
                            ,t_user_voice_comment.voice_id == r.voice_id
                            )
                    ).first()
        v_login_report = DB.session.query(t_user_voice_report
                    ).filter(
                        and_(t_user_voice_report.report_org_id == session.get('orgid')
                            ,t_user_voice_report.report_user_id == session.get('userid')
                            ,t_user_voice_comment.voice_id == r.voice_id
                            )
                    ).first()
        w_user_nm           = ""
        w_user_img_file     = ""
        w_voice_comment_flg = 0
        w_voice_comment_dtm = ""
        w_voice_comment     = ""
        w_good_flg          = 0
        w_report_flg        = 0
        if v_login_user is not None:
            w_user_img_file = v_login_user.profile_img_file
        if v_login_comment is not None:
            w_voice_comment_flg = 1
            w_voice_comment_dtm = v_login_comment.voice_comment_dtm.strftime("%Y/%m/%d %H:%M:%S")
            w_voice_comment     = v_login_comment.voice_comment
        if v_login_good is not None:
            w_good_flg = 1
        if v_login_report is not None:
            w_report_flg = 1
        # データ送信
        emit('sok_cli_ini_voice_comment_login_user'
            , {
                'login_org_id'  : session.get('orgid')
               ,'login_org_nm'  : session.get('orgnm')
               ,'login_user_id' : session.get('userid')
               ,'login_user_nm' : session.get('usernm')
               ,'login_user_img': w_user_img_file
               ,'login_voice_comment_dtm': w_voice_comment_dtm
               ,'login_voice_comment'    : w_voice_comment
               ,'login_voice_comment_flg': w_voice_comment_flg
               ,'login_voice_good_flg'   : w_good_flg
               ,'login_voice_report_flg' : w_report_flg
              }
            )
        # ----------------------------------------------------
        # その他ユーザー
        # ----------------------------------------------------
        # データ取得
        sql_voice_comment = """
            select a.voice_comment
                  ,a.voice_comment_dtm
                  ,a.comment_org_id
                  ,a.comment_user_id
              from t_user_voice_comment a
             where a.voice_id  = @VOICE_ID@
               and (a.comment_org_id, a.comment_user_id) not in (
                select b.comment_org_id, b.comment_user_id
                  from t_user_voice_comment b
                 where b.voice_id        = @VOICE_ID@
                   and b.comment_org_id  = '@LOGIN_ORG_ID@'
                   and b.comment_user_id = '@LOGIN_USER_ID@'
                )
             order by a.voice_comment_dtm desc
             limit 5
        """
        sql_voice_comment = sql_voice_comment.replace("@VOICE_ID@",str(r.voice_id))
        sql_voice_comment = sql_voice_comment.replace("@LOGIN_ORG_ID@",session.get('orgid'))
        sql_voice_comment = sql_voice_comment.replace("@LOGIN_USER_ID@",session.get('userid'))
        rst_voice_comment = DB.session.execute(sql_voice_comment)
        rst_voice_comment = list(rst_voice_comment)
        for r_comment in rst_voice_comment:
            v_comment_user = DB.session.query(m_user
                                    ).filter(
                                        and_(m_user.org_id == r_comment.comment_org_id
                                            ,m_user.user_id == r_comment.comment_user_id
                                            )
                                    ).first()
            v_comment_rep = DB.session.query(t_user_voice_comment_report
                                    ).filter(
                                        and_(t_user_voice_comment_report.comment_org_id == r_comment.comment_org_id
                                            ,t_user_voice_comment_report.comment_user_id == r_comment.comment_user_id
                                            ,t_user_voice_comment_report.report_org_id == session.get('orgid')
                                            ,t_user_voice_comment_report.report_user_id == session.get('userid')
                                            ,t_user_voice_comment_report.voice_id == r.voice_id
                                            )
                                    ).first()
            w_user_nm         = ""
            w_user_img_file   = ""
            w_comment_rep_flg = 0
            if v_comment_user is not None:
                w_user_nm       = v_comment_user.user_nm
                w_user_img_file = v_comment_user.profile_img_file
            if v_comment_rep is not None:
                w_comment_rep_flg = 1
            # データ送信
            emit('sok_cli_ini_voice_comment'
                , {
                    'other_org_id'   : r_comment.comment_org_id
                   ,'other_user_id'  : r_comment.comment_user_id
                   ,'other_user_nm'  : w_user_nm
                   ,'other_user_img' : w_user_img_file
                   ,'other_voice_comment_dtm' : r_comment.voice_comment_dtm.strftime("%Y/%m/%d %H:%M:%S")
                   ,'other_voice_comment'     : r_comment.voice_comment
                   ,'other_comment_report_flg': w_comment_rep_flg
                  }
                )

@SOK.on('sok_srv_ini_profile', namespace='/sok')
def sok_srv_ini_profile(message):
    """
    # 処理： [Socket.io]profile.html初期化処理
    # 概要： 
    # 備考： 
    """
    pass

@SOK.on('sok_srv_ini_search', namespace='/sok')
def sok_srv_ini_search(message):
    """
    # 処理： [Socket.io]search.html初期化処理
    # 概要： 
    # 備考： 
    """
    pass

@SOK.on('sok_srv_ini_management', namespace='/sok')
def sok_srv_ini_management(message):
    """
    # 処理： [Socket.io]management.html初期化処理
    # 概要： 
    # 備考： 
    """
    pass

@SOK.on('sok_srv_ini_analyze', namespace='/sok')
def sok_srv_ini_analyze(message):
    """
    # 処理： [Socket.io]analyze.html初期化処理
    # 概要： 
    # 備考： 
    """
    pass

@SOK.on('connect', namespace='/sok')
def sok_connect():
    """
    # 処理： [Socket.io]WEBソケット接続後処理
    # 概要： 
    # 備考： 
    """
    _create_access_log('/sok_connect')
    global SOK_CON_CNT
    SOK_CON_CNT += 1
    APP.logger.debug(SOK_CON_CNT)
    if session.get('orgid') is not None and session.get('userid') is not None:
        DB.session.query(t_user_status
                ).filter(
                    and_(t_user_status.org_id == session.get('orgid')
                        ,t_user_status.user_id == session.get('userid')
                        )
                ).delete()
        status = t_user_status(org_id=session.get('orgid')
                              ,user_id=session.get('userid')
                              ,status='ONLINE'
                              )
        DB.session.add(status)
        DB.session.commit()

@SOK.on('disconnect', namespace='/sok')
def sok_disconnect():
    """
    # 処理： [Socket.io]WEBソケット切断後処理
    # 概要： 
    # 備考： 
    """
    _create_access_log('/sok_disconnect')
    global SOK_CON_CNT
    SOK_CON_CNT -= 1
    APP.logger.debug(SOK_CON_CNT)
    if session.get('orgid') is not None and session.get('userid') is not None:
        DB.session.query(t_user_status
                ).filter(
                    and_(t_user_status.org_id == session.get('orgid')
                        ,t_user_status.user_id == session.get('userid')
                        )
                ).delete()
        status = t_user_status(org_id=session.get('orgid')
                              ,user_id=session.get('userid')
                              ,status='OFFLINE'
                              )
        DB.session.add(status)
        DB.session.commit()

def _app_start_ini():
    """
    # 処理： アプリケーションサーバ起動時初期化処理
    # 概要： 
    # 備考： 
    """
    rst = DB.session.query(m_user).all()
    DB.session.query(t_user_status).delete()
    for r in rst:
        APP.logger.debug(r.user_id)
        status = t_user_status(org_id=r.org_id
                              ,user_id=r.user_id
                              ,status='OFFLINE'
                              ,upd_dtm='2000/01/01'
                              )
        DB.session.add(status)
        DB.session.commit()

if __name__ == '__main__':
    # DB.reflect()
    # DB.drop_all()
    # DB.create_all()
    # DB.session.commit()
    _app_start_ini()
    APP.debug = True
    SOK.run(APP)
    # SOK.run(APP, host='0.0.0.0')



