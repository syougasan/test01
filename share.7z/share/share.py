from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import *
import json
import os
from flask_socketio import SocketIO, emit

APP = Flask(__name__)
APP.config['SECRET_KEY']                     = os.urandom(24)
APP.config['SQLALCHEMY_DATABASE_URI']        = 'postgresql://postgres@172.16.100.40/pptest'
APP.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
SOK = SocketIO(APP)
DB  = SQLAlchemy(APP)

class m_linked_org(DB.Model):
    __tablename__               = 'm_linked_org'
    linked_org_id               = DB.Column(DB.Text, primary_key=True)
    linked_org_nm               = DB.Column(DB.Text)
    linked_org_auth_cd          = DB.Column(DB.Text)
    linked_org_profile_business = DB.Column(DB.Text)
    linked_org_profile_msg      = DB.Column(DB.Text)
    linked_org_profile_img_file = DB.Column(DB.Text)
    ins_dtm                     = DB.Column(DB.TIMESTAMP)
    upd_dtm                     = DB.Column(DB.TIMESTAMP)
    stop_flg                    = DB.Column(DB.NUMERIC)

class m_linked_org_member(DB.Model):
    __tablename__               = 'm_linked_org_menber'
    linked_org_id               = DB.Column(DB.Text, primary_key=True)
    org_id                      = DB.Column(DB.Text, primary_key=True)

class m_linked_org_auth(DB.Model):
    __tablename__               = 'm_linked_org_auth'
    linked_org_auth_cd          = DB.Column(DB.Text, primary_key=True)
    linked_org_auth_nm          = DB.Column(DB.Text)
    fnc_other_org_online_flg    = DB.Column(DB.NUMERIC)
    fnc_other_org_profile_flg   = DB.Column(DB.NUMERIC)
    fnc_other_org_talk_flg      = DB.Column(DB.NUMERIC)
    fnc_other_org_tweet_flg     = DB.Column(DB.NUMERIC)
    fnc_other_org_search_flg    = DB.Column(DB.NUMERIC)
    fnc_other_org_analyze_flg   = DB.Column(DB.NUMERIC)
    fnc_other_org_footprint_flg = DB.Column(DB.NUMERIC)
    fnc_other_org_notice_flg    = DB.Column(DB.NUMERIC)

class t_linked_org_msg(DB.Model):
    __tablename__       = 't_linked_org_msg'
    linked_org_id       = DB.Column(DB.Text, primary_key=True)
    linked_org_msg_id   = DB.Column(DB.NUMERIC, Sequence('t_linked_org_msg_seq'), primary_key=True)
    linked_org_msg_dtm  = DB.Column(DB.TIMESTAMP, default=func.now())
    linked_org_msg_type = DB.Column(DB.Text)
    linked_org_msg      = DB.Column(DB.Text)
    send_org_id         = DB.Column(DB.Text)
    send_user_id        = DB.Column(DB.Text)

class m_org(DB.Model):
    __tablename__        = 'm_org'
    org_id               = DB.Column(DB.Text, primary_key=True)
    org_nm               = DB.Column(DB.Text)
    org_pass             = DB.Column(DB.Text)
    org_auth_cd          = DB.Column(DB.Text)
    org_profile_business = DB.Column(DB.Text)
    org_profile_address  = DB.Column(DB.Text)
    org_profile_msg      = DB.Column(DB.Text)
    org_profile_img_file = DB.Column(DB.Text)
    ins_dtm              = DB.Column(DB.TIMESTAMP)
    upd_dtm              = DB.Column(DB.TIMESTAMP)
    stop_flg             = DB.Column(DB.NUMERIC)

class m_org_auth(DB.Model):
    __tablename__             = 'm_org_auth'
    org_auth_cd               = DB.Column(DB.Text, primary_key=True)
    org_auth_nm               = DB.Column(DB.Text)
    fnc_one_talk_flg          = DB.Column(DB.NUMERIC)
    fnc_group_talk_flg        = DB.Column(DB.NUMERIC)
    fnc_org_talk_flg          = DB.Column(DB.NUMERIC)
    talk_read_flg             = DB.Column(DB.NUMERIC)
    talk_notice_flg           = DB.Column(DB.NUMERIC)
    talk_img_flg              = DB.Column(DB.NUMERIC)
    talk_stamp_flg            = DB.Column(DB.NUMERIC)
    talk_del_flg              = DB.Column(DB.NUMERIC)
    talk_sanitize_flg         = DB.Column(DB.NUMERIC)
    fnc_tweet_flg             = DB.Column(DB.NUMERIC)
    tweet_share_flg           = DB.Column(DB.NUMERIC)
    tweet_like_flg            = DB.Column(DB.NUMERIC)
    tweet_comment_flg         = DB.Column(DB.NUMERIC)
    tweet_sanitize_flg        = DB.Column(DB.NUMERIC)
    fnc_setting_flg           = DB.Column(DB.NUMERIC)
    setting_user_mng_flg      = DB.Column(DB.NUMERIC)
    setting_user_auth_mng_flg = DB.Column(DB.NUMERIC)
    setting_img_mng_flg       = DB.Column(DB.NUMERIC)
    setting_stamp_mng_flg     = DB.Column(DB.NUMERIC)
    setting_sound_mng_flg     = DB.Column(DB.NUMERIC)
    setting_tag_mng_flg       = DB.Column(DB.NUMERIC)
    setting_footprint_mng_flg = DB.Column(DB.NUMERIC)
    fnc_tag_profile_flg       = DB.Column(DB.NUMERIC)
    tag_profile_limit         = DB.Column(DB.NUMERIC)
    fnc_tag_tweet_flg         = DB.Column(DB.NUMERIC)
    tag_tweet_limit           = DB.Column(DB.NUMERIC)
    fnc_search_flg            = DB.Column(DB.NUMERIC)
    search_org_flg            = DB.Column(DB.NUMERIC)
    search_user_flg           = DB.Column(DB.NUMERIC)
    search_profile_tag_flg    = DB.Column(DB.NUMERIC)
    search_tweet_tag_flg      = DB.Column(DB.NUMERIC)
    fnc_analyze_flg           = DB.Column(DB.NUMERIC)
    analyze_one_talk_flg      = DB.Column(DB.NUMERIC)
    analyze_group_talk_flg    = DB.Column(DB.NUMERIC)
    analyze_tweet_flg         = DB.Column(DB.NUMERIC)
    analyze_access_flg        = DB.Column(DB.NUMERIC)
    fnc_online_flg            = DB.Column(DB.NUMERIC)
    online_last_login_flg     = DB.Column(DB.NUMERIC)
    fnc_footprint_flg         = DB.Column(DB.NUMERIC)
    footprint_del_flg         = DB.Column(DB.NUMERIC)
    fnc_link_flg              = DB.Column(DB.NUMERIC)
    link_limit                = DB.Column(DB.NUMERIC)

class t_org_profile_tag(DB.Model):
    __tablename__ = 't_org_profile_tag'
    org_id        = DB.Column(DB.Text, primary_key=True)
    tag_cd        = DB.Column(DB.Text, primary_key=True)

class t_org_msg(DB.Model):
    __tablename__ = 't_org_msg'
    org_id        = DB.Column(DB.Text, primary_key=True)
    org_msg_id    = DB.Column(DB.NUMERIC, Sequence('t_org_msg_seq'), primary_key=True)
    org_msg_dtm   = DB.Column(DB.TIMESTAMP, default=func.now())
    org_msg_type  = DB.Column(DB.Text) #img or text
    org_msg       = DB.Column(DB.Text)
    send_org_id   = DB.Column(DB.Text)
    send_user_id  = DB.Column(DB.Text)

class t_org_msg_comment(DB.Model):
    __tablename__       = 't_org_msg_comment'
    org_msg_id          = DB.Column(DB.Text, primary_key=True)
    org_msg_comment_dtm = DB.Column(DB.TIMESTAMP, default=func.now())
    org_msg_comment     = DB.Column(DB.Text)
    comment_org_id      = DB.Column(DB.Text, primary_key=True)
    comment_user_id     = DB.Column(DB.Text, primary_key=True)

class t_org_msg_chk(DB.Model):
    __tablename__   = 't_org_msg_chk'
    org_msg_id      = DB.Column(DB.Text, primary_key=True)
    org_msg_chk_dtm = DB.Column(DB.TIMESTAMP, default=func.now())
    chk_org_id      = DB.Column(DB.Text, primary_key=True)
    chk_user_id     = DB.Column(DB.Text, primary_key=True)

class t_org_msg_tag(DB.Model):
    __tablename__ = 't_org_msg_tag'
    org_msg_id    = DB.Column(DB.Text, primary_key=True)
    tag_cd        = DB.Column(DB.Text, primary_key=True)

class m_user(DB.Model):
    __tablename__         = 'm_user'
    org_id                = DB.Column(DB.Text, primary_key=True)
    user_id               = DB.Column(DB.Text, primary_key=True)
    user_nm               = DB.Column(DB.Text)
    user_pass             = DB.Column(DB.Text)
    user_auth_cd          = DB.Column(DB.Text)
    user_profile_work     = DB.Column(DB.Text)
    user_profile_msg      = DB.Column(DB.Text)
    user_profile_img_file = DB.Column(DB.Text)
    login_status          = DB.Column(DB.Text)
    login_last_dtm        = DB.Column(DB.TIMESTAMP)
    ins_dtm               = DB.Column(DB.TIMESTAMP)
    upd_dtm               = DB.Column(DB.TIMESTAMP)
    stop_flg              = DB.Column(DB.NUMERIC)

class m_user_auth(DB.Model):
    __tablename__              = 'm_user_auth'
    user_auth_cd               = DB.Column(DB.Text, primary_key=True)
    user_auth_nm               = DB.Column(DB.Text)
    site_base_collor           = DB.Column(DB.Text)
    site_position_type         = DB.Column(DB.Text)
    talk_one_flg               = DB.Column(DB.NUMERIC)
    talk_one_make_flg          = DB.Column(DB.NUMERIC)
    talk_group_flg             = DB.Column(DB.NUMERIC)
    talk_group_make_flg        = DB.Column(DB.NUMERIC)
    talk_org_flg               = DB.Column(DB.NUMERIC)
    talk_linked_org_flg        = DB.Column(DB.NUMERIC)
    setting_flg                = DB.Column(DB.NUMERIC)
    analyze_flg                = DB.Column(DB.NUMERIC)
    notice_sound_nm            = DB.Column(DB.Text)
    notice_talk_one_flg        = DB.Column(DB.NUMERIC)
    notice_talk_group_flg      = DB.Column(DB.NUMERIC)
    notice_talk_org_flg        = DB.Column(DB.NUMERIC)
    notice_talk_linked_org_flg = DB.Column(DB.NUMERIC)
    notice_tweet_share_flg     = DB.Column(DB.NUMERIC)
    notice_tweet_like_flg      = DB.Column(DB.NUMERIC)
    notice_tweet_comment_flg   = DB.Column(DB.NUMERIC)
    notice_online_flg          = DB.Column(DB.NUMERIC)

class m_user_order(DB.Model):
    __tablename__  = 'm_user_order'
    user_id        = DB.Column(DB.Text, primary_key=True)
    order_user_id  = DB.Column(DB.Text, primary_key=True)
    order_user_seq = DB.Column(DB.NUMERIC)

class t_user_profile_tag(DB.Model):
    __tablename__ = 't_user_profile_tag'
    org_id        = DB.Column(DB.Text, primary_key=True)
    user_id       = DB.Column(DB.Text, primary_key=True)
    tag_cd        = DB.Column(DB.Text, primary_key=True)

class t_user_profile_footprint(DB.Model):
    __tablename__ = 't_user_profile_footprint'
    org_id        = DB.Column(DB.Text, primary_key=True)
    user_id       = DB.Column(DB.Text, primary_key=True)
    visit_org_id  = DB.Column(DB.Text, primary_key=True)
    visit_user_id = DB.Column(DB.Text, primary_key=True)
    footprint_dtm = DB.Column(DB.Text, primary_key=True)

class t_user_tweet(DB.Model):
    __tablename__ = 't_user_tweet'
    org_id        = DB.Column(DB.Text, primary_key=True)
    user_id       = DB.Column(DB.Text, primary_key=True)
    tweet_id      = DB.Column(DB.Text, Sequence('t_user_tweet_seq'), primary_key=True)
    tweet_dtm     = DB.Column(DB.TIMESTAMP, default=func.now())
    tweet         = DB.Column(DB.Text)

class t_user_tweet_comment(DB.Model):
    __tablename__     = 't_user_tweet_comment'
    tweet_id          = DB.Column(DB.Text, primary_key=True)
    tweet_comment_dtm = DB.Column(DB.TIMESTAMP, default=func.now())
    tweet_comment     = DB.Column(DB.Text)
    comment_org_id    = DB.Column(DB.Text, primary_key=True)
    comment_user_id   = DB.Column(DB.Text, primary_key=True)

class t_user_tweet_like(DB.Model):
    __tablename__  = 't_user_tweet_like'
    tweet_id       = DB.Column(DB.Text, primary_key=True)
    tweet_like_dtm = DB.Column(DB.TIMESTAMP, default=func.now())
    tweet_like     = DB.Column(DB.Text)
    like_org_id    = DB.Column(DB.Text, primary_key=True)
    like_user_id   = DB.Column(DB.Text, primary_key=True)

class t_user_tweet_tag(DB.Model):
    __tablename__ = 't_user_tweet_tag'
    tweet_id      = DB.Column(DB.Text, primary_key=True)
    tag_cd        = DB.Column(DB.Text, primary_key=True)

class t_user_tweet_follow(DB.Model):
    __tablename__  = 't_user_tweet_follow'
    org_id         = DB.Column(DB.Text, primary_key=True)
    user_id        = DB.Column(DB.Text, primary_key=True)
    follow_org_id  = DB.Column(DB.Text, primary_key=True)
    follow_user_id = DB.Column(DB.Text, primary_key=True)

class m_tag(DB.Model):
    __tablename__ = 'm_tag'
    tag_kbn_cd    = DB.Column(DB.Text, primary_key=True)
    tag_kbn_nm    = DB.Column(DB.Text)
    tag_cd        = DB.Column(DB.Text, primary_key=True)
    tag_nm        = DB.Column(DB.Text)

class t_user_talk(DB.Model):
    __tablename__  = 't_user_talk'
    org_id         = DB.Column(DB.Text, primary_key=True)
    user_talk_id   = DB.Column(DB.NUMERIC, Sequence('t_user_talk_seq'), primary_key=True)
    user_talk_nm   = DB.Column(DB.Text)
    user_talk_type = DB.Column(DB.Text) #1:1 group

class t_user_talk_member(DB.Model):
    __tablename__ = 't_user_talk_member'
    org_id        = DB.Column(DB.Text, primary_key=True)
    user_talk_id  = DB.Column(DB.NUMERIC, primary_key=True)
    user_id       = DB.Column(DB.Text, primary_key=True)

class t_user_talk_msg(DB.Model):
    __tablename__ = 't_user_talk_msg'
    org_id        = DB.Column(DB.Text, primary_key=True)
    user_talk_id  = DB.Column(DB.NUMERIC, primary_key=True)
    talk_msg_id   = DB.Column(DB.NUMERIC, Sequence('t_user_talk_msg_seq'), primary_key=True)
    talk_msg_dtm  = DB.Column(DB.TIMESTAMP, default=func.now())
    talk_msg_type = DB.Column(DB.Text) #img or text
    talk_msg      = DB.Column(DB.Text)
    send_org_id   = DB.Column(DB.Text)
    send_user_id  = DB.Column(DB.Text)

class t_access_log(DB.Model):
    __tablename__ = 't_access_log'
    log_seq       = DB.Column(DB.NUMERIC, Sequence('t_access_log_seq'), primary_key=True)
    org_id        = DB.Column(DB.Text)
    user_id       = DB.Column(DB.Text)
    ip            = DB.Column(DB.Text)
    url           = DB.Column(DB.Text)
    record_dtm    = DB.Column(DB.TIMESTAMP, default=func.now())

def _create_access_log(url):
    log = t_access_log(org_id='1' #session.get('orgid')
                      ,user_id='u001' #session.get('userid')
                      ,ip=request.remote_addr
                      ,url=url
                      )
    DB.session.add(log)
    DB.session.commit()

@APP.before_request
def before_request():  
    if session.get('userid') is not None:
        return
    if request.path == '/login':
        return
    # return redirect('/login')
    return

@APP.route('/login', methods=['GET', 'POST'])
def login():
    _create_access_log('/login')
    if request.method == 'POST':
        if _is_account_valid():
            session['userid'] = request.form['userid']
            return redirect(url_for('index'))
        return render_template('login.html', errmsg="ログイン情報に誤りがあります")
    return render_template('login.html')

def _is_account_valid():  
    userid   = request.form.get('userid')
    password = request.form.get('password')
    rst      = m_user.query.filter(and_(m_user.user_id == userid, m_user.user_pass == password)).first()
    if rst is not None:
        return True
    return False

@APP.route('/logout')
def logout():
    _create_access_log('/logout')
    session.pop('userid', None)
    return redirect(url_for('login'))

@APP.route('/')
def index():
    _create_access_log('/index')
    try:
        rst_m_user = DB.session.query(m_user
                        ).filter(m_user.stop_flg == 0
                        ).order_by(m_user.user_id
                        ).all()
        # rst_m_user = DB.session.query(m_user).filter(and_(m_user.user_id != session.get('userid') ,m_user.stop_flg == 0)).order_by(m_user.user_id).all()
        rst_login_user = DB.session.query(m_user
                            ).filter(
                                and_(m_user.user_id == 'u001' # session.get('userid')
                                    ,m_user.stop_flg == 0)
                            ).first()
        # rst_login_user = DB.session.query.filter(m_user.user_id == session.get('userid')).first()
        rst_ins_user_aft_login_user = DB.session.query(m_user
                                                      ,func.to_char(m_user.ins_dtm, 'YYYY-MM-dd')
                                        ).filter(
                                            and_(m_user.user_id != 'u001' # session.get('userid')
                                                ,m_user.ins_dtm >= rst_login_user.login_last_dtm)
                                        ).all()
    except Exception as e:
        APP.logger.warning(e)
    return render_template('index.html'
                          ,rst_m_user=rst_m_user
                          ,rst_ins_user_aft_login_user=rst_ins_user_aft_login_user
                          ,now_dtm=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                          )

@APP.route('/profile')
def profile():
    _create_access_log('/profile')
    return render_template('profile.html')

@APP.route('/search')
def search():
    _create_access_log('/search')
    return render_template('search.html')

@APP.route('/setting')
def setting():
    _create_access_log('/setting')
    return render_template('setting.html')

@APP.route('/analyze')
def analyze():
    _create_access_log('/analyze')
    return render_template('analyze.html')

@SOK.on('my_event', namespace='/sok')
def sok_message(message):
    import urllib.parse
    aaa = message['data']
    bbb = urllib.parse.unquote(aaa)
    cht = t_chat_one_to_one(msg=bbb
                           ,send_user_id=session.get('userid')
                           ,resv_user_id="hoge"
                           )
    DB.session.add(cht)
    DB.session.commit()
    now = datetime.now().strftime("%Y/%m/%d %H:%M:%S")
    emit('my_response'
        , {
            'data': bbb
           ,'dtm' : now
           ,'send_user_id' : session.get('userid')
           ,'resv_user_id' : "hoge"
          }
        ,broadcast=True
        )

@SOK.on('connect', namespace='/sok')
def sok_connect():
    emit('my response', {'data': 'Connected'})

@SOK.on('disconnect', namespace='/sok')
def sok_disconnect():
    print('Client disconnected')

if __name__ == '__main__':
    # DB.reflect()
    # DB.drop_all()
    # DB.create_all()
    # DB.session.commit()
    APP.debug = True
    SOK.run(APP, host='0.0.0.0')
