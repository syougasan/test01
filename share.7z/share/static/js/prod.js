/* ------------------------------------------ */
/* グローバル変数                                 */
/* ------------------------------------------ */
_SOK = io.connect('http://' + document.domain + ':' + location.port + '/sok');
/* ------------------------------------------ */
/* 処理: 検索スクロール                           */
/* 概要:                                      */
/* 引数: なし                                   */
/* ------------------------------------------ */
function fnc_search_scroll() {
    // スクロールのオフセット値
    var offsetY = -95;
    // スクロールにかかる時間
    var time = 500;
    // 移動先となる要素を取得
    var id = document.getElementById('user_search').value
    fnc_box_collapse(id.replace("#", ""),event,1);
    document.getElementById('nav_toggle').click();
    var target = $('#collapse_' + id.replace("#", ""));
    if (!target.length) return;
    // 移動先となる値
    var targetY = target.offset().top + offsetY;
    // スクロールアニメーション
    $('html,body').animate({ scrollTop: targetY }, time, 'swing');
    // ハッシュ書き換えとく
    // window.history.pushState(null, null, $(www));
    // デフォルトの処理はキャンセル
    return false;
};
/* ------------------------------------------ */
/* 処理: 前回ログイン時期を返す                     */
/* 概要:                                      */
/* 引数:                                      */
/* ------------------------------------------ */
function fnc_get_last_login_timing(now, last) {
    if (last == "None") { return "未ログイン"; }
    now_dtm        = new Date(now)
    last_login_dtm = new Date(last)
    var diff       = now_dtm.getTime() - last_login_dtm.getTime();
    var day        = Math.floor(diff / 1000 / 60 / 60 / 24);
    var hour       = Math.floor(diff / 1000 / 60 / 60);
    var min        = Math.floor(diff / 1000 / 60);
    var second     = Math.floor(diff / 1000);
    last_login_timing = "Now!!"
    if (day >= 365) {
        last_login_timing = "未ログイン"
    } else if (day >= 30) {
        last_login_timing = "1ヶ月以上"
    } else if (day >= 1) {
        last_login_timing = day + 1 + "日以内"
    } else if (hour >= 1) {
        last_login_timing = hour + 1 + "時間以内"
    } else if (min >= 1) {
        last_login_timing = min + 1 + "分以内"
    }
    return last_login_timing
};
/* ------------------------------------------ */
/* 処理: ユーザーボックス 開閉                      */
/* 概要:                                      */
/* 引数:                                      */
/* ------------------------------------------ */
function fnc_box_collapse(box_id,event,search_flg) {
    if($(event.target).is('a')) {
    } else {
        if(search_flg == 1) {
            var box_height = document.getElementById('box_' + box_id).clientHeight;
            if(box_height <= 100) {
                document.getElementById('collapse_' + box_id).click();
            }
        } else {
            document.getElementById(box_id.id).click();
        }
    }
}
/* ------------------------------------------ */
/* 処理: ユーザーボックス 並び替え                   */
/* 概要:                                      */
/* 引数:                                      */
/* ------------------------------------------ */
// $(function() {
//     // get ajax
//     // loop
//     $('#dummy_box').after($('#box_u007'));
// });
/* ------------------------------------------ */
/* 処理: ログイン状況アイコン                       */
/* 概要:                                      */
/* 引数:                                      */
/* ------------------------------------------ */
function fnc_login_status_icon(state) {
    if (!state.id) { return state.text; }
    if (state.element.label == 'ONLINE') {
        var $state = $(
            // '<span><i class="fa fa-circle text-gray"></i>&nbsp' + state.text +'</span>'
            '<span><i class="fa fa-circle text-green"></i>&nbsp' + state.text + '</span>'
        );
    } else {
        var $state = $(
            '<span><i class="fa fa-circle text-gray"></i>&nbsp' + state.text + '</span>'
        );
    }
    return $state;
};
/* ------------------------------------------ */
/* 処理: マスタ管理アイコン                         */
/* 概要:                                      */
/* 引数:                                      */
/* ------------------------------------------ */
function fnc_mst_mng_icon(state) {
    if (!state.id) { return state.text; }
    var $state = $(
        '<span><i class="fa fa-table"></i>&nbsp' + state.text + '</span>'
    );
    return $state;
};
/* ------------------------------------------ */
/* 処理: テキストエリア動的リサイズ                    */
/* 概要:                                      */
/* 引数:                                      */
/* ------------------------------------------ */
function fnc_textarea_resize(Tarea){ 
    var areaH = Tarea.style.height;
    if(Tarea.value == ""){areaH=26+"px";}
    areaH = parseInt(areaH) - 30;
    if(areaH < 30){areaH = 30}
    Tarea.style.height = areaH + "px";
    Tarea.style.height = (parseInt(Tarea.scrollHeight)) + "px";
}
/* -------------------------------------------------------------- */
/* 処理: [Socket.io]ボイスコメント通知受信処理                           */
/* 概要:                                                          */
/* 受信内容:                                                       */
/*   msg.comment_org_id  : ボイスコメント登録ユーザー 組織ID               */
/*   msg.comment_user_id : ボイスコメント登録ユーザー ユーザーID             */
/*   msg.comment_user_nm : ボイスコメント登録ユーザー ユーザー名             */
/*   msg.comment_user_img: ボイスコメント登録ユーザー イメージ画像           */
/*   msg.voice_comment   : ボイスコメント登録ユーザ コメント                 */
/*   msg.voice_org_id    : ボイス発信者 組織ID                        */
/*   msg.voice_org_nm    : ボイス発信者 組織名                        */
/*   msg.voice_user_id   : ボイス発信者 ユーザーID                      */
/*   msg.voice_user_nm   : ボイス発信者 ユーザー名                      */
/* ------------------------------------------------------------- */
_SOK.on('sok_cli_add_voice_comment', function(msg) {
    var login_org_id  = $('[id^=login_user_icon_]').attr("id").split("_")[3]
    var login_user_id = $('[id^=login_user_icon_]').attr("id").split("_")[4]
    if ((msg.voice_org_id == login_org_id) && (msg.voice_user_id == login_user_id)) {
        if (!msg.comment_user_img) {
            var w_comment_user_img = "noimage.png"
        } else {
            var w_comment_user_img = msg.comment_user_img
        }
        var disp_html =   "<div style='padding-top:5px; min-height:40px;'>"
                        +   "<span>"
                        +       "<strong>[新着コメント]</strong><br>"
                        +       "<small>" + "yyyy/mm/dd hh24:mi:ss"  + "</small>"
                        +   "</span><br>"
                        +   "<img class='img-circle img-sm' src='/static/img/user/" + w_comment_user_img + "'>"
                        +   "<label style='padding-left:5px; margin-bottom:10px;margin-top:5px'>" + msg.comment_user_nm + "</label><br>"
                        + "</div>"
        $('[id^=login_user_icon_]').tooltipster({
           content: $(disp_html),
           animation: 'fade',
           theme: ['tooltipster-light', 'tooltipster-light-customized'],
           timer: 5000,
           arrow: false,
           trigger: 'custom'
        }); 
        $('[id^=login_user_icon_]').tooltipster('open');
    }
})
