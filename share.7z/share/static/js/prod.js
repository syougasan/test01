/* ------------------------------------------ */
/* 検索スクロール                                 */
/* ------------------------------------------ */
function search_scroll() {
    // スクロールのオフセット値
    var offsetY = -95;
    // スクロールにかかる時間
    var time = 500;
    // 移動先となる要素を取得
    var www = document.getElementById('user_search').value
    document.getElementById(www.replace("#", "")).click();
    document.getElementById('nav_toggle').click();
    var target = $(www);
    if (!target.length) return;
    // 移動先となる値
    var targetY = target.offset().top + offsetY;
    // スクロールアニメーション
    $('html,body').animate({ scrollTop: targetY }, time, 'swing');
    // ハッシュ書き換えとく
    // window.history.pushState(null, null, $(www));
    // デフォルトの処理はキャンセル
    return false;
};
/* ------------------------------------------ */
/* ユーザーボックス 開閉                            */
/* ------------------------------------------ */
function diff_dtm(now, last) {
    if (last == "None") { return "未ログイン"; }
    now_dtm        = new Date(now)
    last_login_dtm = new Date(last)
    var diff       = now_dtm.getTime() - last_login_dtm.getTime();
    var day        = Math.floor(diff / 1000 / 60 / 60 / 24);
    var hour       = Math.floor(diff / 1000 / 60 / 60);
    var min        = Math.floor(diff / 1000 / 60);
    var second     = Math.floor(diff / 1000);
    dtm = "Now!!"
    if (day >= 30) {
        dtm = "1ヶ月以上"
    } else if (day >= 1) {
        dtm = day + 1 + "日以内"
    } else if (hour >= 1) {
        dtm = hour + 1 + "時間以内"
    } else if (min >= 1) {
        dtm = min + 1 + "分以内"
    }
    return dtm
};
/* ------------------------------------------ */
/* ユーザーボックス 開閉                            */
/* ------------------------------------------ */
function box_collapse(box_id) {
    document.getElementById(box_id.id).click();
}
/* ------------------------------------------ */
/* ユーザーボックス 並び替え                         */
/* ------------------------------------------ */
// $(function() {
//     // get ajax
//     // loop
//     $('#dummy_box').after($('#box_u007'));
// });
/* ------------------------------------------ */
/* ログイン状況アイコン                             */
/* ------------------------------------------ */
function login_state_icon(state) {
    if (!state.id) { return state.text; }
    if (state.element.label == 'LOGIN') {
        var $state = $(
            // '<span><i class="fa fa-circle text-gray"></i>&nbsp' + state.text +'</span>'
            '<span><i class="fa fa-circle text-green"></i>&nbsp' + state.text + '</span>'
        );
    } else {
        var $state = $(
            '<span><i class="fa fa-circle text-gray"></i>&nbsp' + state.text + '</span>'
        );
    }
    return $state;
};
/* ------------------------------------------ */
/* マスタ管理アイコン                               */
/* ------------------------------------------ */
function mst_mng_icon(state) {
    if (!state.id) { return state.text; }
    var $state = $(
        '<span><i class="fa fa-table"></i>&nbsp' + state.text + '</span>'
    );
    return $state;
};
