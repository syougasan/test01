import bcrypt
salt = bcrypt.gensalt(rounds=10, prefix=b'2a')
password = b'password'
aaa = bcrypt.hashpw(password, salt)
vvv = bcrypt.hashpw(password, salt)
if aaa == vvv :
    print(aaa)
    print(vvv)



