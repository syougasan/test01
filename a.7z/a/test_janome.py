from janome.tokenizer import Tokenizer

t      = Tokenizer()
tokens = t.tokenize(u"うらにわにはにわとりがいる")

for token in tokens:
    w_str = token.part_of_speech.split(",")[0]
    if ( w_str == "名詞" or w_str == "形容詞" or w_str == "動詞"):
        print(token.surface + " " + w_str)


